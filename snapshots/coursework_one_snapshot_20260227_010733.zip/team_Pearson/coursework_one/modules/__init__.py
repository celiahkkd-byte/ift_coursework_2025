"""Top-level package for coursework pipeline modules."""
