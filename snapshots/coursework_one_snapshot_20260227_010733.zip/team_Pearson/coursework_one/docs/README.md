# Documentation Workspace

Build Sphinx HTML docs from project root:

```bash
cd docs/sphinx
poetry run make html
```

Output site entry:
- `docs/sphinx/build/html/index.html`
